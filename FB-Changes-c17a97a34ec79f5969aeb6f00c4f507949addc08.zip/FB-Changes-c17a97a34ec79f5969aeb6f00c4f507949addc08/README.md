# Greasemonkey

Firefox Addon: https://addons.mozilla.org/en-US/firefox/addon/greasemonkey

Fake News Changes Script: https://github.com/garrettgriess/FB-Changes/blob/master/facebook-fakenews_changes.js

Political Changes Script: https://github.com/garrettgriess/FB-Changes/blob/master/facebook-political_changes.js

Screen Shot: https://github.com/garrettgriess/FB-Changes/blob/master/facebook-political_changes.gif

# Facebook Political Changes Plugins: (older)

Firefox Add-On: https://github.com/garrettgriess/greasemonkey-scripts/blob/master/fb_changes-0.10-an%2Bfx.xpi

Chrome Extension: https://chrome.google.com/webstore/detail/fb-changes/poaflpemcnjghjclkkenliabbiililbo
